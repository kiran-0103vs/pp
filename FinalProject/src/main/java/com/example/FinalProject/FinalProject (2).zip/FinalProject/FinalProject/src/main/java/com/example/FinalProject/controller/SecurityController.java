package com.example.FinalProject.controller;

import com.example.FinalProject.FileUploadUtility;
import com.example.FinalProject.model.Home;
import com.example.FinalProject.model.Security;
import com.example.FinalProject.service.HomeService;
import com.example.FinalProject.service.SecurityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@RestController
@RequestMapping("/secure")
public class SecurityController {
    @Autowired
    private SecurityService securityService;
    //public  static String uploadDirectory=System.getProperty("user.dir")+"/src/main/webapp/imagess";


    @PostMapping("/add")
    public String add(@RequestBody Security s){
        securityService.save(s);
        return "New student is added";
    }

    @GetMapping("/getAll")
    public List<Security> list(){
        return securityService.getAllDetails();
    }

    @GetMapping("/getUserName")
    public String getUserNameByEmail(@RequestParam String email) {
        return securityService.findNameByEmail(email);
    }



}
