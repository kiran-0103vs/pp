package com.example.FinalProject.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Locale;
@Data
@Entity
@Table (name="security")
public class Security {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    public Security(int id, String name, String relative, String relative_name, String email, String background, String image) {
        this.id = id;
        this.name = name;
        this.relative = relative;
        this.relative_name = relative_name;
        this.email = email;
        this.background = background;
        this.image = image;
    }

    private String name;
    private String relative;
    private String relative_name;
    private String email;
    private String background;
    private String image;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getRelative() {
        return relative;
    }

    public void setRelative(String relative) {
        this.relative = relative;
    }

    public String getRelative_name() {
        return relative_name;
    }

    public void setRelative_name(String relative_name) {
        this.relative_name = relative_name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBackground() {
        return background;
    }

    public void setBackground(String background) {
        background=background.toLowerCase();
        String ans="";
        switch(background)
        {
            case "black":
                ans="blk";
                break;
            case "white":
                ans="whe";
                break;
            case "red":
                ans="red";
                break;
            case "pink":
                ans="pik";
                break;
            case "violet":
                ans="vit";
                break;
            case "blue":
                ans="ble";
                break;
            case "orange":
                ans="ore";
                break;
            case "yellow":
                ans="yew";
                break;


        }

        int b = (int)(Math.random()*(2-0+1)+0);
        char a[]=ans.toCharArray();
        a[b]=Character.toUpperCase(a[b]);
        ans=String.valueOf(a);
        this.background=ans;






    }

    public Security() {
    }

    @Override
    public String toString() {
        return "Security{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", relative='" + relative + '\'' +
                ", relative_name='" + relative_name + '\'' +
                ", email='" + email + '\'' +
                ", background='" + background + '\'' +
                ", image='" + image + '\'' +
                '}';
    }
}
