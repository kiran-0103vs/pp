package com.example.FinalProject.service;

import com.example.FinalProject.model.Home;
import com.example.FinalProject.model.Security;
import com.example.FinalProject.repository.SecurityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SecurityService {
    //private static SecurityRepository securityRepository;
    @Autowired
    private SecurityRepository securityRepository;

    public Security save(Security s)
    {
        return securityRepository.save(s);

    }

    public List<Security> getAllDetails() {
        return securityRepository.findAll();
    }

    public  String findNameByEmail(String email) {
        Optional<Security> userOptional = securityRepository.findByEmail(email);
        return userOptional.map(Security::getBackground).orElse("User not found");
    }


}



